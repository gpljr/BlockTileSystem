﻿public class BulletHitEvent : GameEvent
{

    public BulletHitEvent()
    {

    }


}
