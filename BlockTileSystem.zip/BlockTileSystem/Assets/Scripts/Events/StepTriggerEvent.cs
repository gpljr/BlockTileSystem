﻿public class StepTriggerEvent : GameEvent
{
    public int triggerID;
    public StepTriggerEvent(int triggerID)
    {
        this.triggerID = triggerID;
    }


}
