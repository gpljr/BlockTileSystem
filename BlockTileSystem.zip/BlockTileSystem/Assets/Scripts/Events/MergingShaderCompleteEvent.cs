﻿public class MergingShaderCompleteEvent : GameEvent
{

    public MergingShaderCompleteEvent()
    {
    }


}
