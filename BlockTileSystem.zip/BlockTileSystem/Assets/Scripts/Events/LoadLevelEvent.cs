﻿public class LoadLevelEvent : GameEvent
{
public int iLevel;
    public LoadLevelEvent(int iLevel)
    {
        this.iLevel = iLevel;
    }


}
